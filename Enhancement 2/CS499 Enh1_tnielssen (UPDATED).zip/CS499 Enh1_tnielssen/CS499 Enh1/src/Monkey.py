from RescueAnimal import RescueAnimal


# subclass Monkey is a child of RescueAnimal
class Monkey(RescueAnimal):
    #  Instance variable
    species = str()
    tailLength = str()
    height = str()
    bodyLength = str()

    #  Constructor
    def __init__(self, name, species, gender, age, weight, tailLength, height, bodyLength, acquisitionDate,
                 acquisitionCountry, trainingStatus, reserved, inServiceCountry):
        super(Monkey, self).__init__()
        super().set_name(name)
        super().set_animal_type(species)
        super().set_gender(gender)
        super().set_age(age)
        super().set_weight(weight)
        super().set_tail_length(tailLength)
        super().set_height(height)
        super().set_body_length(bodyLength)
        super().set_acquisition_date(acquisitionDate)
        super().set_acquisition_location(acquisitionCountry)
        super().set_training_status(trainingStatus)
        super().set_reserved(reserved)
        super().set_in_service_country(inServiceCountry)
