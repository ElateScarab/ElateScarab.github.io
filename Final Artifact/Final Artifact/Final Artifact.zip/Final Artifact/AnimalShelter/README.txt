This program runs in the console of your favorite IDE.

In Visual Studio, open the AnimalShelter folder and select the Driver class.
Then, in the top ribbon, click Run -> Run without Debugging -> Default python configuration.