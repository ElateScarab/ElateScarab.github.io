from RescueAnimal import RescueAnimal


# subclass Dog is a child of RescueAnimal
class Dog(RescueAnimal):
    #  Instance variable
    breed = str()

    #  Constructor
    def __init__(self, name, breed, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved,
                 inServiceCountry):
        super(Dog, self).__init__()
        super().set_name(name)
        super().set_breed(breed)
        super().set_gender(gender)
        super().set_age(age)
        super().set_weight(weight)
        super().set_acquisition_date(acquisitionDate)
        super().set_acquisition_location(acquisitionCountry)
        super().set_training_status(trainingStatus)
        super().set_reserved(reserved)
        super().set_in_service_country(inServiceCountry)
