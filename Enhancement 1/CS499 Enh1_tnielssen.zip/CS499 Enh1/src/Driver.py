from src.Dog import Dog
from src.Monkey import Monkey

dog_list = []
monkey_list = []


def main():
    initialize_dog_list()
    initialize_monkey_list()
    display_menu()

    # Setting up the main menu options to reference the other methods

    user_input = input()
    if user_input == '1':
        intake_new_dog()
    elif user_input == '2':
        intake_new_monkey()
    elif user_input == '3':
        reserve_animal()
    elif user_input == '4':
        print_animals('4')
    elif user_input == '5':
        print_animals('5')
    elif user_input == '6':
        print_animals('6')
    elif user_input == 'q':
        exit(0)
    else:
        print("Select a valid menu option")  # Input validation for the menu
        display_menu()
        user_input = input()


# This method prints the menu options
def display_menu():
    print("\n\n")
    print("\t\t\t\tRescue Animal System Menu")
    print("[1] Intake a new dog")
    print("[2] Intake a new monkey")
    print("[3] Reserve an animal")
    print("[4] Print a list of all dogs")
    print("[5] Print a list of all monkeys")
    print("[6] Print a list of all animals that are not reserved")
    print("[q] Quit application")
    print()
    print("Enter a menu selection")


# Adds dogs to a list for testing
def initialize_dog_list():
    dog1 = Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "intake", False,
               "United States")
    dog2 = Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "Phase I", False,
               "United States")
    dog3 = Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", True, "Canada")

    dog_list.append(dog1)
    dog_list.append(dog2)
    dog_list.append(dog3)


# Adds a monkey to a list for testing
def initialize_monkey_list():
    monkey1 = Monkey("Jack", "Marmoset", "male", "3", "12", "14", "34", "40", "03-21-2018", "Peru", "in service", False,
                     "United States")

    monkey_list.append(monkey1)


# Method to add a new dog to the array list
def intake_new_dog():
    print("What is the dog's name?")
    name = input()
    for dog in dog_list:
        if dog.get_name().lower() == name.lower():
            print("\n\nThis dog is already in our system\n\n")
            return  # returns to menu
        else:

            # Referencing the mutators in class RescueAnimal
            dog.set_name(name)

            print("Breed:")
            dog.set_breed(input())

            print("Gender:")
            dog.set_gender(input())

            print("Age:")
            dog.set_age(input())

            print("Weight:")
            dog.set_weight(input())

            print("Country acquired:")
            dog.set_acquisition_date(input())

            print("Date acquired:")
            dog.set_acquisition_location(input())

            print("Training status:")
            dog.set_training_status(input())

            print("Reserved? (true/false)")
            dog.set_reserved(input().lower() == 'true')

            if dog.get_reserved():
                print("Country of service:")
                dog.set_in_service_country(input())
            print("New dog has been added.")

            display_menu()
            return


# Method to add a new monkey to the array list
def intake_new_monkey():
    print("What is the monkey's name?")
    name = input()
    for monkey in monkey_list:
        if monkey.get_name().lower() == name.lower():
            print("\n\nThis monkey is already in our system\n\n")
            return
        else:
            # Check the monkey species to make sure it is acceptable to Grazioso
            print("Species: ")
            species = input()
            if species.lower() not in ["capuchin", "guenon", "macaque", "marmoset", "squirrel monkey", "tamarin"]:
                print("We currently are not accepting this species of monkey.")
                return

            # Reference mutators from class RescueAnimal to set attributes
            monkey.set_name(name)

            print("Gender: ")
            monkey.set_gender(input())

            print("Age: ")
            monkey.set_age(input())

            print("Weight: ")
            monkey.set_weight(input())

            print("Tail length: ")
            monkey.set_tail_length(input())

            print("Height: ")
            monkey.set_height(input())

            print("Body length: ")
            monkey.set_body_length(input())

            print("Acquisition date: ")
            monkey.set_acquisition_date(input())

            print("Acquisition country: ")
            monkey.set_acquisition_location(input())

            print("Training status: ")
            monkey.set_training_status(input())

            print("Reserved status: ")
            monkey.set_reserved(input().lower() == 'true')

            if monkey.get_reserved():
                print("Country of service: ")
                monkey.set_in_service_country(input())
            print("New monkey has been added.")
            display_menu()
            return


# Method allowing a user to select an animal to reserve from the list
def reserve_animal():
    print("Enter desired animal type:")  # Querying user for animal type
    animal_type = input()
    print("Enter desired animal country:")  # Querying user for animal country
    in_service_country = input()
    if animal_type.lower() == "dog":
        for dog in dog_list:
            if dog.get_in_service_country().lower() == in_service_country.lower():
                # Updating the reserved status
                dog.set_reserved(True)
                print(dog.get_name() + " has been reserved for you.")
                break
        # error handling in case the specified animal is not available
        else:
            print("It doesn't look like we have a dog available that matches your criteria.")
            print("Please check your spelling or try another country.")
            display_menu()
    elif animal_type.lower() == "monkey":
        for monkey in monkey_list:
            if monkey.get_in_service_country().lower() == in_service_country.lower():
                # Updating the reserved status
                monkey.set_reserved(True)
                print(monkey.get_name() + " has been reserved for you.")
                break
        # error handling in case the specified animal is not available
        else:
            print("It doesn't look like we have a monkey available that matches your criteria.")
            print("Please check your spelling or try another country.")
            display_menu()
    # Error handling if the user selects anything besides a dog or a monkey
    else:
        print("That is not a valid choice. Grazioso Salvare only trains dogs and monkeys at this time.")
        print("Please check your spelling or enter a valid choice (dog or monkey).")
        display_menu()


# Prints a list of animals based on the selection a user makes from the main menu
def print_animals(choice):
    if choice == '4':
        # Displays name, training status, reserved status, and country
        for dog in dog_list:
            print(f"Name: {dog.get_name()} Training status: {dog.get_training_status()} Reserved: {dog.get_reserved()}")
            print("Country: " + dog.get_in_service_country())
            print("----------")
        display_menu()
    elif choice == '5':
        # Displays name, training status, reserved status, and country
        for monkey in monkey_list:
            print(f"Name: {monkey.get_name()} Training status: {monkey.get_training_status()} "
                  f"Reserved: {monkey.get_reserved()}")
            print("Country: " + monkey.get_in_service_country())
            print("----------")
        display_menu()
    elif choice == '6':
        print("Animals that are not currently reserved:")
        for dog in dog_list:
            if dog.get_in_service_country() and not dog.get_reserved():
                print(f"Name: {dog.get_name()} Type: Dog")
                print(f"Training status: {dog.get_training_status()} Country: {dog.get_in_service_country()}")
                print("----------")
        for monkey in monkey_list:
            if monkey.get_in_service_country() and not monkey.get_reserved():
                print(f"Name: {monkey.get_name()} Type: Monkey")
                print(f"Training status: {monkey.get_training_status()} Country: {monkey.get_in_service_country()}")
                print("----------")
        display_menu()


# Run the program
if __name__ == "__main__":
    main()
